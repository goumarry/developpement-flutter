# USAGE-IA — TP 4 — Goumarre Yoann

Outil(s) utilisé(s) : ChatGPT (GPT-4) + Claude (assistant intégré à l'éditeur), ponctuellement
Déclaration : [x] entrées ci-dessous

## Entrée 1
- Date et heure : 09/09/2026, ~10h
- Partie du TP concernée : Partie A
- Pourquoi j'ai sollicité l'IA : je voulais être sûr de bien comprendre pourquoi
  `setState` au niveau 1 reconstruit `EventSection` (niveau 2) même quand ce
  widget ne se sert pas de la donnée, avant de rédiger le constat A.2.
- Ce que j'ai demandé : « en Flutter, si un StatefulWidget parent fait setState,
  est-ce que tous ses enfants Stateless sont reconstruits même s'ils ne
  reçoivent pas de nouveau paramètre ? »
- Ce que j'ai obtenu : oui, `setState` reconstruit toute la méthode `build` du
  widget, donc tout le sous-arbre créé dans ce `build` ; seuls les sous-arbres
  `const` sont épargnés.
- Décision : acceptée telle quelle (explication)
- Correction apportée et vérification faite : vérifié moi-même avec les
  compteurs `builds` de l'écran de démo (6/6/6 pour 5 incréments) avant de
  l'écrire dans le README.

## Entrée 2
- Date et heure : 09/09/2026, ~11h30
- Partie du TP concernée : Partie B.2 (règles métier du panier)
- Pourquoi j'ai sollicité l'IA : hésitation sur la façon de renvoyer un « signal
  exploitable » pour les refus — exception dédiée, booléen, ou enum ?
- Ce que j'ai demandé : comparaison des trois approches pour signaler l'échec
  d'un `addRegistration` (doublon / complet / plafond).
- Ce que j'ai obtenu : recommandation d'un `enum` de résultat (lisible côté
  appelant, pas de `try/catch` partout, facile à mapper vers un message).
- Décision : acceptée après adaptation
- Si refusée ou corrigée, pourquoi : la version proposée mélangeait le message
  utilisateur (« Événement complet ») dans l'enum, ce qui aurait fait dépendre
  `registration_cart.dart` d'une logique de présentation. J'ai gardé un enum
  « sec » (`rejectedEventFull`, etc.) et déplacé la traduction en message dans
  `utils/cart_feedback.dart` (couche UI).
- Correction apportée et vérification faite : `grep -rE 'material|widgets'
  lib/state/` → aucun résultat ; `flutter analyze` OK. Les trois refus testés à
  la main sur émulateur (SnackBar rouge à chaque fois).

## Entrée 3
- Date et heure : 09/09/2026, ~12h
- Partie du TP concernée : Partie B.5 / choix watch·read·select
- Pourquoi j'ai sollicité l'IA : je voulais que le badge et une tuile ne se
  reconstruisent pas inutilement quand j'ajoute au panier un *autre* événement.
- Ce que j'ai demandé : comment ne reconstruire une tuile que lorsque le nombre
  de places réservées pour *son* événement change.
- Ce que j'ai obtenu : `context.select<RegistrationCart, int>((c) =>
  c.seatsForEvent(event.id))` — la tuile ne se reconstruit que si cette valeur
  précise change.
- Décision : acceptée telle quelle
- Correction apportée et vérification faite : ajouté un `debugPrint` par
  `build` de tuile. Mesure : 5 ajouts sur 5 événements → `EventSection` et
  `EventListScreen` = 0 reconstruction, `EventTile` = +1 pour la seule tuile
  touchée (les autres restent à 1). Consigné dans le README.

## Entrée 4
- Date et heure : 09/09/2026, ~14h
- Partie du TP concernée : Partie A (panneau de compteurs de l'écran de démo)
- Pourquoi j'ai sollicité l'IA : mon panneau qui affiche les compteurs `builds`
  restait bloqué sur « 1 » alors que la console montrait bien 6.
- Ce que j'ai demandé : pourquoi un `StatefulWidget` déclaré `const` dans la
  liste d'un `ListView` ne se reconstruit pas quand le parent fait `setState`.
- Ce que j'ai obtenu : un widget `const` est canonicalisé → l'élément voit la
  même instance à chaque frame → `updateChild` court-circuite et ne reconstruit
  pas. Il faut lui passer une valeur qui change (ici le compteur).
- Décision : acceptée après correction
- Si refusée ou corrigée, pourquoi : la première proposition (rebuild via un
  `Timer.periodic`) marchait mais reconstruisait le panneau 3×/seconde pour
  rien. J'ai préféré passer `tick: _registrationCount` et resynchroniser une
  seule fois par incrément via `addPostFrameCallback` dans `didUpdateWidget`
  (le panneau lit alors les compteurs une fois le badge d'AppBar reconstruit).
- Correction apportée et vérification faite : panneau à jour après 5 « + 1 »
  (6/6/6), cohérent avec la console. `flutter analyze` OK.

## Bilan
- Sur quoi l'IA m'a réellement fait gagner du temps : le choix « enum de
  résultat + traduction en couche UI » pour les refus métier, et le réflexe
  `context.select` sur une clé fine plutôt que `watch` global.
- Sur quoi elle m'a coûté du temps : elle a d'abord fait fuiter la présentation
  dans le notifier (message dans l'enum) ; et le débogage du panneau `const` qui
  ne se rafraîchissait pas m'a pris un moment avant de comprendre la
  canonicalisation.
- Ce que je saurais refaire sans elle à l'issue de ce TP : modéliser un
  `ChangeNotifier` avec des règles métier internes et un résultat typé, l'exposer
  via `ChangeNotifierProvider` / `MultiProvider`, et choisir consciemment entre
  `watch` (tout l'écran dépend de l'état), `select` (une tranche précise) et
  `read` (mutation hors `build`). La différence état local / état global est
  maintenant claire pour moi.
